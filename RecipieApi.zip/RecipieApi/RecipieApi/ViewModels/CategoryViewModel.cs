﻿namespace RecipieApi.ViewModels
{
    public class CategoryViewModel
    {
        public string Name { get; set; }
        public IFormFile Photo { get; set; }
    }
}
