﻿namespace RecipieApi.Models
{
    public class Class
    {
    }
}
